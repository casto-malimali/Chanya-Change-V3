<!DOCTYPE html>
<html>
<head>
    <title>New Contact Form Submission</title>
</head>
<body>
    <h2>Contact Form Submission</h2>
    <p><strong>Name:</strong> <?php echo e($contactData['fname']); ?></p>
    <p><strong>Phone:</strong> <?php echo e($contactData['phone']); ?></p>
    <p><strong>Email:</strong> <?php echo e($contactData['email']); ?></p>
    <p><strong>Service Type:</strong> <?php echo e($contactData['type']); ?></p>
    <p><strong>Message:</strong> <?php echo e($contactData['msg']); ?></p>
</body>
</html>
<?php /**PATH E:\Code-droid\ChanyaChange_Web\resources\views/mail/contact.blade.php ENDPATH**/ ?>