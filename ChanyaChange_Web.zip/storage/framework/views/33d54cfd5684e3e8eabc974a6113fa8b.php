<!DOCTYPE html>
<html>
<head>
    <title>New Contact Form Submission</title>
</head>
<body>
    <h2>Contact Form Submission</h2>
    <p><strong>Name:</strong> <?php echo e($communityData['name']); ?></p>
    <p><strong>Phone:</strong> <?php echo e($communityData['phone']); ?></p>
    <p><strong>Email:</strong> <?php echo e($communityData['email']); ?></p>
    <p><strong>Joined as:</strong> <?php echo e($communityData['communityType']); ?></p>
    <p><strong>Description:</strong> <?php echo e($communityData['description']); ?></p>
</body>
</html>
<?php /**PATH E:\Code-droid\ChanyaChange_Web\resources\views/mail/community.blade.php ENDPATH**/ ?>