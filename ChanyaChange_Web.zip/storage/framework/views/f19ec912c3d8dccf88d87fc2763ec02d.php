<!DOCTYPE html>
<html>
<head>
    <title>New Chat Form Submission</title>
</head>
<body>
<p>Dear, <i>Madam Pam</i></p>
<p>Hope this email finds you well.</p>
<p>Please review the data from the Chanyachange website</p>
    <h2>Chat Form Submission</h2>
    <p><strong>Name:</strong> <?php echo e($chatData['name']); ?></p>
    <p><strong>Phone:</strong> <?php echo e($chatData['phone']); ?></p>
    <p><strong>Email:</strong> <?php echo e($chatData['email']); ?></p>
    <p><strong>Message:</strong> <?php echo e($chatData['msg']); ?></p>
</body>
</html>
<?php /**PATH E:\Code-droid\ChanyaChange_Web\resources\views/mail/chat.blade.php ENDPATH**/ ?>