AOS.init({
    duration: 10000,
    offset: 120,
    easing: 'ease-in-out'
})
